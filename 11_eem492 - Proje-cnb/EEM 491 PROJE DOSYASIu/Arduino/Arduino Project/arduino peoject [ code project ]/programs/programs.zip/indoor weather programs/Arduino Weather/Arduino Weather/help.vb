﻿Public Class help
    Private Sub help_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = My.Resources.help
    End Sub
End Class