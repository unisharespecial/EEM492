CadStd Drawing files open with CadStd Lite v3.7.0

SCH files open with eagle 5.6.1

Processing Source Code opens with Arduino 0017 or wordpad

PDF files open with Adobe Reader 8

Dynamic Draw files open with Dynamic Draw 5

Microsoft visual studio files open with visual basic

.cpp or .h files open with visual C++ or wordpad

.vb files can be opened with wordpad
