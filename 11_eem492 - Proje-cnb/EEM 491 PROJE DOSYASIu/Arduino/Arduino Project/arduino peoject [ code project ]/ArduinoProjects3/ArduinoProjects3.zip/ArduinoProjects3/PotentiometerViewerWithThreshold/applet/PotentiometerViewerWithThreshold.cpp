// Potentiometer viewer with threshold

// Constants
#include "WProgram.h"
void setup();
void loop();
const int POT_PIN = 0;                  // Pot connected to analog pin 0
const int POT_THRESHOLD = 3;            // Threshold amount to guard against false values
const int SERIAL_PORT_RATE = 9600;


void setup()                            // Run once, when the sketch starts
{
    pinMode(POT_PIN, INPUT);            // Sets the potentiometer as input
    Serial.begin(SERIAL_PORT_RATE);     // Starts communication with the MIDI out port
}

void loop()                             // Run over and over again
{
     static int s_nLastPotValue = 0;
    static int s_nLastMappedValue = 0;

   int nCurrentPotValue = analogRead(POT_PIN);
    if(abs(nCurrentPotValue - s_nLastPotValue) < POT_THRESHOLD)
        return;
    s_nLastPotValue = nCurrentPotValue;

    int nMappedValue = map(nCurrentPotValue, 0, 1023, 0, 127);      // Map the value to 0-127
    if(nMappedValue == s_nLastMappedValue)
        return;
    s_nLastMappedValue = nMappedValue;


    Serial.println(nMappedValue);
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

