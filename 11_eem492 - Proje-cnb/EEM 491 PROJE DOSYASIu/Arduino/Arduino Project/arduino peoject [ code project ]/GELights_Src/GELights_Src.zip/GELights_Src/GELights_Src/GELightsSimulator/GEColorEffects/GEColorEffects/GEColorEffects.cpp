// If PC is defined then it compiles for the PC ... else compile for the Arudino

#ifdef PC
#define _CRT_SECURE_NO_WARNINGS 1
#include <tchar.h>
#include <stdio.h>
#include <string.h>
#include <tchar.h>
#endif

#include "GEColorEffects.pde"

#ifdef PC
bool _trace = false;

int _tmain(int argc, _TCHAR* argv[])
{
	// zero out the file name
	strcpy(&_programfile[0][0], "");
	strcpy(&_programfile[1][0], "");
	strcpy(&_programfile[2][0], "");
	strcpy(&_programfile[3][0], "");
	strcpy(&_programfile[4][0], "");
	strcpy(&_programfile[5][0], "");

	// get the names of the files from the command line
	size_t i;
	int start = 1;

	if (wcscmp(argv[1], L"-T") == 0 || wcscmp(argv[1], L"-t") == 0)
	{
		_trace = true;
		start = 2;
	}

	for (int k = start; k < argc; k++)
	{
		wcstombs_s(&i, &_programfile[k-start][0], 1024, argv[k], 1024);
	}

	// run setup
	setup();

	// run program
	while(TRUE)
	{
		loop();
	}

	// return success
	return 0;
}
#endif
