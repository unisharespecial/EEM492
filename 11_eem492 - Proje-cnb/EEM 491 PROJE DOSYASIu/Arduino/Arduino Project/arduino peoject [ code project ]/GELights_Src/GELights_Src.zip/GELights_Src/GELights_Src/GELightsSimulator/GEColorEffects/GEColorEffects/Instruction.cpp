#include "global.h"
#include "Instruction.h"
#include "LinkedListVar.h"

#ifdef PC
	#include <stdio.h>
	#include "cppfix.h"
#endif

// special values
#define RANDOMBULB -16050
#define NOCOLOUR -16051
#define NOBRIGHTNESS -16052
#define RANDOMBRIGHTNESS -16053
#define RANDOMALLONEBRIGHTNESS -16054
#define RANDOMSTEPBRIGHTNESS -16055
#define RANDOMALLONECOLOUR -16056
#define RANDOMCOLOUR -16057
#define RANDOMSTEPCOLOUR -16058

extern short cycleinterval; // refer to the cycle time interval declared in GEColorEffects.cpp

// Create an instruction
void Instruction::BaseConstruct(LightsString* string, short args[])
{
	// save the type
	_string = string;
}

// set a variable
void Instruction::SetVar(short var, short val)
{
	// pass this to the string
	_string->SetVar(var, val);
}

// get a variable
short Instruction::GetVarOrValue(short var)
{
	if (LinkedListVar::IsVariable(var))
	{
		// pass this to the string
		return _string->GetVar(var);
	}
	else
	{
		// not a variable so just return the var as if it was a value
		return var;
	}
}

// Get the number of parameters a command needs
byte Instruction::Parameters(byte type)
{
	#ifdef PC
		// return the number of parameters for the provided command type
		return _parameters[type];
	#else
		return pgm_read_byte_near(_parameters + type);
	#endif
}

// Create the Pause instruction
// Parameters: msecs
void Pause::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check parameters
		if ((args[0] < 1 || args[0] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("Pause::Construct Invalid milliseconds %d.\n", args[0]);
			error(4);
		}
	#endif

	// save the parameters
	_msecs = GetVarOrValue(args[0]);
}

// Check if the instruction is done
bool Pause::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Execute the instruction
void Pause::Execute()
{
	#ifdef PC
		printf("   Pin: %d - PAUSE %d msecs.\n", _string->GetBulb(0)->Pin(), _msecs);

		// sleep for the nominated number of milliseconds
		Sleep((DWORD)_msecs);
	#else
		// sleep for the nominated number of milliseconds
		delay(_msecs);
	#endif
}

// Create the SetColour instruction
// Parameters: startbulb, endbulb, colour, brightness
void SetColour::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]) && args[0] != RANDOMBULB)
		{
			printf("SetColour::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49)  && !LinkedListVar::IsVariable(args[1]))
		{
			printf("SetColour::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("SetColour::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] & 0xF000) > 0 && args[2] != NOCOLOUR && args[2] != RANDOMALLONECOLOUR && args[2] != RANDOMCOLOUR  && !LinkedListVar::IsVariable(args[2]))
		{
			printf("SetColour::Construct Invalid colour 0x%X.\n", args[2]);
			error(4);
		}
		if ((args[3] < 0 || args[3] > 255)  && !LinkedListVar::IsVariable(args[3]) && args[3] != NOBRIGHTNESS && args[3] != RANDOMBRIGHTNESS && args[3] != RANDOMALLONEBRIGHTNESS)
		{
			printf("SetColour::Construct Invalid brightness %d.\n", args[3]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	_colour = GetVarOrValue(args[2]);
	_brightness = (byte)GetVarOrValue(args[3]);
}

// Check if the instruction is done
bool SetColour::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Set the colour
void SetColour::Execute()
{
	short randomcolour = Bulb::RandomColour(); // a random bulb colour
	byte randombrightness = Bulb::RandomBrightness(); // a random brightness
	byte s; // the determined start bulb
	byte e; // the determined end bulb

	// handle random bulb
	if (_startbulb == (byte)(RANDOMBULB))
	{
		s = Bulb::RandomBulb();
		e = s;
	}
	else
	{
		// not random so use those passed in
		s = _startbulb;
		e = _endbulb;
	}

	#ifdef PC
		printf("   Pin: %d - SETCOLOUR %d-%d.\n", _string->GetBulb(0)->Pin(), s, e);
	#endif

	// for each bulb in range
	for (byte i = s; i <= e; i++)
	{
		// as long as the colour is not -1
		if (_colour == NOCOLOUR)
		{
			// no new colour
		}
		else if (_colour == RANDOMALLONECOLOUR)
		{
			// set the colour to the random colour
			_string->GetBulb(i)->SetColour(randomcolour);
		}
		else if (_colour == RANDOMCOLOUR)
		{
			// set the colour to a random colour
			_string->GetBulb(i)->SetColour(Bulb::RandomColour());
		}
		else
		{
			// set the colour
			_string->GetBulb(i)->SetColour(_colour);
		}

		// as long as the brightness is not -1
		if (_brightness == NOBRIGHTNESS)
		{
			// no new brightness
		}
		else if (_brightness == RANDOMALLONEBRIGHTNESS)
		{
			// set the brightness
			_string->GetBulb(i)->SetBrightness(randombrightness);
		}
		else if (_brightness == RANDOMBRIGHTNESS)
		{
			// set the brightness
			_string->GetBulb(i)->SetBrightness(Bulb::RandomBrightness());
		}
		else
		{
			// set the brightness
			_string->GetBulb(i)->SetBrightness(_brightness);
		}

		// send the set colour command
		_string->GetBulb(i)->Display();
	}
}

// Create the SetAllBrightness instruction
// Parameters: startbulb, endbulb, colour, brightness
void SetAllBrightness::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check parameters
		if ((args[0] < 0 || args[0] > 255) && args[0] != RANDOMALLONEBRIGHTNESS  && !LinkedListVar::IsVariable(args[0]))
		{
			printf("SetAllBrightness::Construct Invalid brightness %d.\n", args[0]);
			error(4);
		}
	#endif

	// save the parameters
	_brightness = (byte)GetVarOrValue(args[0]);
}

// Check if the instruction is done
bool SetAllBrightness::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Set all the bulbs to the same brightness
void SetAllBrightness::Execute()
{
	#ifdef PC
		printf("   Pin: %d - SETALLBRIGHTNESS.\n", _string->GetBulb(0)->Pin());
	#endif

	byte randombrightness = Bulb::RandomBrightness(); // a random bulb brightness

	// for each bulb
	for (byte i = 0; i < 50; i++)
	{
		if (_brightness == RANDOMALLONEBRIGHTNESS)
		{
			// set the brightness
			_string->GetBulb(i)->SetBrightness(randombrightness);
		}
		else
		{
			// set the brightness
			_string->GetBulb(i)->SetBrightness(_brightness);
		}
	}

	if (_brightness == RANDOMALLONEBRIGHTNESS)
	{
		// set the all bulbs bulb brightness
		_string->GetBulb(63)->SetBrightness(randombrightness);
	}
	else
	{
		// set the all bulbs bulb brightness
		_string->GetBulb(63)->SetBrightness(_brightness);
	}

	// send the all bulbs set brightness command
	_string->GetBulb(63)->Display();
}

// Create the AdjustBrightness instruction
// Parameters: startbulb, endbulb, colour, brightness
void AdjustBrightness::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("AdjustBrightness::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("AdjustBrightness::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("AdjustBrightness::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
		}
		if ((args[2] < -255 || args[2] > 255) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("AdjustBrightness::Construct Invalid adjustment amount %d.\n", args[2]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	_amount = GetVarOrValue(args[2]);
}

// Check if the instruction is done
bool AdjustBrightness::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Adjust the brightness of the bulbs by the amount
void AdjustBrightness::Execute()
{
	#ifdef PC
		printf("   Pin: %d - ADJUSTBRIGHTNESS %d-%d by %d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb, _amount);
	#endif

	// for each bulb in the range
	for (byte i = _startbulb; i <= _endbulb; i++)
	{
		// adjust the bulb brightness by the nominated amount
		_string->GetBulb(i)->SetBrightness(_string->GetBulb(i)->Brightness() + _amount);

		// Send the new brighntness to the bulb
		_string->GetBulb(i)->Display();
	}
}

// Create the AdjustAllBrightness instruction
// Parameters: startbulb, endbulb, colour, brightness
void AdjustAllBrightness::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < -255 || args[0] > 255) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("AdjustAllBrightness::Construct Invalid adjustment amount %d.\n", args[0]);
			error(4);
		}
	#endif

	// save the parameters
	_amount = GetVarOrValue(args[0]);
}

// Check if the instruction is done
bool AdjustAllBrightness::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Adjust the brightness of all bulbs by the amount
void AdjustAllBrightness::Execute()
{
	#ifdef PC
		printf("   Pin: %d - ADJUSTALLBRIGHTNESS by %d.\n", _string->GetBulb(0)->Pin(), _amount);
	#endif

	// adjust the brightness of the broadcast bulb
	_string->GetBulb(63)->SetBrightness(_string->GetBulb(63)->Brightness() + _amount);

	// send the command to all bulbs
	_string->GetBulb(63)->Display();

	// for each bulb
	for (byte i = 0; i < 50; i++)
	{
		// set the brightness to the new brightness
		_string->GetBulb(i)->SetBrightness(_string->GetBulb(63)->Brightness());
	}
}

// Create the SetCycleInterval instruction
// Parameters: startbulb, endbulb, colour, brightness
void SetCycleInterval::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("SetCycleInterval::Construct Invalid milliseconds %d.\n", args[0]);
			error(4);
		}
	#endif

	// save the parameters
	_msecs = GetVarOrValue(args[0]);
}

// Check if the instruction is done
bool SetCycleInterval::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Set the cycle interval delay time
void SetCycleInterval::Execute()
{
	#ifdef PC
		printf("   Pin: %d - SETCYCLEINTERVAL to %d.\n", _string->GetBulb(0)->Pin(), _msecs);
	#endif

	// set the value
	cycleinterval = _msecs;
}

// Create the AdjustCycleInterval instruction
// Parameters: amount, cycles
void AdjustCycleInterval::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < -16000 || args[0] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("AdjustCycleInterval::Construct Invalid adjustment amount %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 1 || args[1] > 16000) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("AdjustCycleInterval::Construct Invalid cycles %d.\n", args[1]);
			error(4);
		}
	#endif

	// save the parameters
	_amount = GetVarOrValue(args[0]);
	_left = GetVarOrValue(args[1]);
}

// Check if the instruction is done
bool AdjustCycleInterval::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Adjust the cycle interval by the given amount each cycle
void AdjustCycleInterval::Execute()
{
	#ifdef PC
		printf("   Pin: %d - ADJUSTCYCLEINTERVAL by %d.\n", _string->GetBulb(0)->Pin(), _amount);
	#endif


	// set the new cycle interval
	cycleinterval = cycleinterval + _amount;

	// if this is less than zero
	if (cycleinterval < 0)
	{
		// set it to zero
		cycleinterval = 0;
	}

	// one less cycle left
	_left--;
}

float ShortFloat::GetFloat(unsigned short i)
{
	return ((float)i)/100;
}

unsigned short ShortFloat::GetShort(unsigned short i)
{
	return i/100;
}

unsigned short ShortFloat::SaveFloat(float f)
{
	return (unsigned short)(f * 100);
}

unsigned short ShortFloat::SaveShort(unsigned short i)
{
	return (i * 100);
}

unsigned short ShortFloat::Add(unsigned short i, float f)
{
	if (ShortFloat::GetFloat(i) + f > (float)15)
	{
		return ShortFloat::SaveShort(15);
	}
	else if (ShortFloat::GetFloat(i) + f < (float)0)
	{
		return ShortFloat::SaveShort(0);
	}
	else
	{
		return ShortFloat::SaveFloat(ShortFloat::GetFloat(i) + f);
	}
}

// Create the FadeColour instruction
// Parameters: startbulb, endbulb, startcolour, endcolour, cycles
void FadeColour::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("FadeColour::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("FadeColour::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("FadeColour::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] & 0xF000) > 0 && args[2] != RANDOMALLONECOLOUR && !LinkedListVar::IsVariable(args[2]))
		{
			printf("FadeColour::Construct Invalid start colour 0x%X.\n", args[2]);
			error(4);
		}
		if ((args[3] & 0xF000) > 0 && args[2] != RANDOMALLONECOLOUR && !LinkedListVar::IsVariable(args[3]))
		{
			printf("FadeColour::Construct Invalid end colour 0x%X.\n", args[3]);
			error(4);
		}
		if ((args[4] < 1 || args[4] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("FadeColour::Construct Invalid cycles %d.\n", args[4]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	//_startcolour = args[2];
	//_endcolour = args[3];
	_left = GetVarOrValue(args[4]);
	_cycles = GetVarOrValue(args[4]);

	if (args[2] == RANDOMALLONECOLOUR)
	{
		// get a random colour
		short randomcolour = Bulb::RandomColour();

		// set the current colour to the start colour
		_red = ShortFloat::SaveShort((randomcolour & 0xF00) >> 8);
		_green = ShortFloat::SaveShort((randomcolour & 0x0F0) >> 4);
		_blue = ShortFloat::SaveShort((randomcolour & 0x00F));
	}
	else
	{
		// set the current colour to the start colour
		_red = ShortFloat::SaveShort((GetVarOrValue(args[2]) & 0xF00) >> 8);
		_green = ShortFloat::SaveShort((GetVarOrValue(args[2]) & 0x0F0) >> 4);
		_blue = ShortFloat::SaveShort((GetVarOrValue(args[2]) & 0x00F));
	}

	if (args[3] == RANDOMALLONECOLOUR)
	{
		// get a random colour
		short randomcolour = Bulb::RandomColour();

		// work out the amount of change required
		_diff =
			((((randomcolour & 0xF00) >> 8) - (byte)ShortFloat::GetShort(_red)) << 8) +
			((((randomcolour & 0x0F0) >> 4) - (byte)ShortFloat::GetShort(_green)) << 4) +
			(randomcolour & 0x00F) - (byte)ShortFloat::GetShort(_blue);
	}
	else
	{
		// work out the amount of change required
		_diff =
			(abs(((GetVarOrValue(args[3]) & 0xF00) >> 8) - (byte)ShortFloat::GetShort(_red)) << 8) +
			(abs(((GetVarOrValue(args[3]) & 0x0F0) >> 4) - (byte)ShortFloat::GetShort(_green)) << 4) +
			abs((GetVarOrValue(args[3]) & 0x00F) - (byte)ShortFloat::GetShort(_blue));

		if (((GetVarOrValue(args[3]) & 0xF00) >> 8) < ShortFloat::GetShort(_red))
		{
			// negative
			_diff = _diff | 0x8000;
		}
		if (((GetVarOrValue(args[3]) & 0x0F0) >> 4) < ShortFloat::GetShort(_green))
		{
			// negative
			_diff = _diff | 0x4000;
		}
		if ((GetVarOrValue(args[3]) & 0x00F) < ShortFloat::GetShort(_blue))
		{
			// negative
			_diff = _diff | 0x2000;
		}
	}
}

// Check if the instruction is done
bool FadeColour::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Set the colour fading from start to end colour over cycles
void FadeColour::Execute()
{
	#ifdef PC
		printf("   Pin: %d - FADECOLOUR %d-%d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb);
	#endif

	// calculate the new colour
	if (_diff & 0x8000)
	{
		_red = ShortFloat::Add(_red, -1*((_diff & 0xF00) >> 8)/(float)_cycles);
	}
	else
	{
		_red = ShortFloat::Add(_red, ((_diff & 0xF00) >> 8)/(float)_cycles);
	}
	if (_diff & 0x4000)
	{
		_green= ShortFloat::Add(_green, -1*((_diff & 0x0F0) >> 4)/(float)_cycles);
	}
	else
	{
		_green = ShortFloat::Add(_green, ((_diff & 0x0F0) >> 4)/(float)_cycles);
	}
	if (_diff & 0x2000)
	{
		_blue = ShortFloat::Add(_blue, -1*(_diff & 0x00F)/(float)_cycles);
	}
	else
	{
		_blue = ShortFloat::Add(_blue, (_diff & 0x00F)/(float)_cycles);
	}

	// convert it to a 12bit colour
	short colour = (((int)ShortFloat::GetShort(_red)) << 8) + (((int)ShortFloat::GetShort(_green)) << 4) + (int)ShortFloat::GetShort(_blue);

	// for each bulb in range
	for (byte i = _startbulb; i <= _endbulb; i++)
	{
		// set the colour
		_string->GetBulb(i)->SetColour(colour);

		// Send the new colour to the bulb
		_string->GetBulb(i)->Display();
	}

	// one less cycle left
	_left--;
}

// Create the FadeBrightness instruction
// Parameters: startbulb, endbulb, startbrightness, endbrightness, cycles
void FadeBrightness::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("FadeBrightness::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("FadeBrightness::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("FadeBrightness::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] < 0 || args[2] > 255) && args[2] != RANDOMALLONEBRIGHTNESS && !LinkedListVar::IsVariable(args[2]))
		{
			printf("FadeBrightness::Construct Invalid start brightness %d.\n", args[2]);
			error(4);
		}
		if ((args[3] < 0 || args[3] > 255) && args[3] != RANDOMALLONEBRIGHTNESS && !LinkedListVar::IsVariable(args[3]))
		{
			printf("FadeBrightness::Construct Invalid end brightness %d.\n", args[3]);
			error(4);
		}
		if ((args[4] < 1 || args[4] > 16000) && !LinkedListVar::IsVariable(args[4]))
		{
			printf("FadeBrightness::Construct Invalid cycles %d.\n", args[1]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	//_startbrightness = args[2];
	//_endbrightness = args[3];
	_cycles = GetVarOrValue(args[4]);
	_left = GetVarOrValue(args[4]);

	if (args[2] == RANDOMALLONEBRIGHTNESS)
	{
		// get a random brightness
		_brightness = (float)Bulb::RandomBrightness();
	}
	else
	{
		// start with the start brightness
		_brightness = (float)args[2];
	}

	if (args[3] == RANDOMALLONEBRIGHTNESS)
	{
		// end at an random brightness
		_brightnessdiff = Bulb::RandomBrightness() - (short)_brightness;
	}
	else
	{
		_brightnessdiff = args[3] - (short)_brightness;
	}
}

// Check if the instruction is done
bool FadeBrightness::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Fade the brightness over the cycles
void FadeBrightness::Execute()
{
	#ifdef PC
		printf("   Pin: %d - FADEBRIGHTNESS %d-%d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb);
	#endif

	// work out the new brightness
	_brightness = _brightness + ((float)_brightnessdiff)/(float)_cycles;

	// for each bulb in range
	for (byte i = _startbulb; i <= _endbulb; i++)
	{
		// set the new bulb brightness
		_string->GetBulb(i)->SetBrightness((int)_brightness);

		// if this is not going to all bulbs
		if (_startbulb != 0 || _endbulb != 49)
		{
			// send the new brightness to the bulb
			_string->GetBulb(i)->Display();
		}
	}

	// if all bulbs are in range then we can use the broadcast brightness command
	if (_startbulb == 0 && _endbulb == 49)
	{
		// set the brightness
		_string->GetBulb(63)->SetBrightness((int)_brightness);

		// send the broadcast command
		_string->GetBulb(63)->Display();
	}

	// one less cycle left
	_left--;
}

// Create the DoNothing instruction
// Parameters: startbulb, endbulb, startbrightness, endbrightness, cycles
void DoNothing::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 1 || args[0] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("DoNothing::Construct Invalid cycles %d.\n", args[0]);
			error(4);
		}
	#endif

	// save the parameters
	_left = GetVarOrValue(args[0]);
}

// Check if the instruction is done
bool DoNothing::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Do nothing for a cycle
void DoNothing::Execute()
{
	#ifdef PC
		printf("   Pin: %d - DONOTHING.\n", _string->GetBulb(0)->Pin());
	#endif

	// one less cycle left
	_left--;
}

// Create the ShiftBulbs instruction
// Parameters: startbulb, endbulb, step, newcolour, newbrightness, cycles
void ShiftBulbs::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("ShiftBulbs::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("ShiftBulbs::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("ShiftBulbs::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] < -49 || args[2] > 49 || args[2] < -1 * (args[1] - args[0]) || args[2] > (args[1] - args[0])) && !LinkedListVar::IsVariable(args[2]) && !LinkedListVar::IsVariable(args[0])&& !LinkedListVar::IsVariable(args[1]) && args[0] != RANDOMBULB)
		{
			printf("ShiftBulbs::Construct Invalid step amount %d.\n", args[2]);
			error(4);
		}
		if ((args[2] < -1 * (args[1] - args[0]) / 2 || args[2] > (args[1] - args[0]) / 2) && !LinkedListVar::IsVariable(args[2]) && !LinkedListVar::IsVariable(args[0]) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("ShiftBulbs::Construct WARNING Innefficent step amount %d.\n", args[2]);
		}
		if (((args[3] & 0xF000) > 0) && args[3] != RANDOMALLONECOLOUR && args[3] != RANDOMCOLOUR && args[3] != NOCOLOUR && args[3] != RANDOMSTEPCOLOUR && !LinkedListVar::IsVariable(args[3]))
		{
			printf("ShiftBulbs::Construct Invalid new colour 0x%X.\n", args[3]);
			error(4);
		}
		if ((args[4] < 0 || args[4] > 255) && !LinkedListVar::IsVariable(args[4]) && args[4] != NOBRIGHTNESS && args[4] != RANDOMBRIGHTNESS && args[4] != RANDOMALLONEBRIGHTNESS && args[4] != RANDOMSTEPBRIGHTNESS)
		{
			printf("ShiftBulbs::Construct Invalid new brightness %d.\n", args[4]);
			error(4);
		}
		if (args[3] == NOCOLOUR && args[4] == NOBRIGHTNESS)
		{
			printf("ShiftBulbs::Construct NewColour and NewBrightness can't be both NOCOLOUR and NOBRIGHTNESS as nothing will be done.");
			error(4);
		}
		if ((args[5] < 1 || args[5] > 16000) && !LinkedListVar::IsVariable(args[5]))
		{
			printf("ShiftBulbs::Construct Invalid cycles %d.\n", args[5]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	_step = GetVarOrValue(args[2]);
	_newcolour = GetVarOrValue(args[3]);
	_newbrightness = (byte)GetVarOrValue(args[4]);
	_left = GetVarOrValue(args[5]);

	if (_newcolour == RANDOMALLONECOLOUR)
	{
		// allocate a random colour
		_randomcolour = Bulb::RandomColour();
	}

	if (_newbrightness == RANDOMALLONEBRIGHTNESS)
	{
		// allocate a random brightness
		_randombrightness = Bulb::RandomBrightness();
	}
}

// Check if the instruction is done
bool ShiftBulbs::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Shift the bulbs replacing the gaps with a given colour
void ShiftBulbs::Execute()
{
	#ifdef PC
		printf("   Pin: %d - SHIFTBULBS %d-%d by %d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb, _step);
	#endif

	// get a random colour and brightness in case we need them
	short randomcolour = Bulb::RandomColour();
	byte randombrightness = Bulb::RandomBrightness();

	// if we are shifting to the right
	if(_step > 0)
	{
		// move the bulbs
		for (byte i = _endbulb;  i >= _startbulb + _step; i--)
		{
			if (_newcolour != NOCOLOUR)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(i-_step)->Colour());
			}
			if (_newbrightness != NOBRIGHTNESS)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(i-_step)->Brightness());
			}
			_string->GetBulb(i)->Display();
		}

		// fill in the gaps with the new colour
		for (byte i = _startbulb; i < _startbulb + _step; i++)
		{
			if (_newcolour == NOCOLOUR)
			{
				// dont change the colour
			}
			else if (_newcolour == RANDOMALLONECOLOUR)
			{
				// set it to our random colour
				_string->GetBulb(i)->SetColour(_randomcolour);
			}
			else if (_newcolour == RANDOMCOLOUR)
			{
				// set it to a new random colour
				_string->GetBulb(i)->SetColour(Bulb::RandomColour());
			}
			else if (_newcolour == RANDOMSTEPCOLOUR)
			{
				// set it to our random colour for this step
				_string->GetBulb(i)->SetColour(randomcolour);
			}
			else
			{
				_string->GetBulb(i)->SetColour(_newcolour);
			}
			if (_newbrightness == NOBRIGHTNESS)
			{
				// dont change the brightness
			}
			else if (_newbrightness == RANDOMALLONEBRIGHTNESS)
			{
				// set it to our random brightness
				_string->GetBulb(i)->SetBrightness(_randombrightness);
			}
			else if (_newbrightness == RANDOMBRIGHTNESS)
			{
				// set it to a new random brightness
				_string->GetBulb(i)->SetBrightness(Bulb::RandomBrightness());
			}
			else if (_newbrightness == RANDOMSTEPBRIGHTNESS)
			{
				// set it to our random brightness for this step
				_string->GetBulb(i)->SetBrightness(randombrightness);
			}
			else
			{
				_string->GetBulb(i)->SetBrightness(_newbrightness);
			}
			_string->GetBulb(i)->Display();
		}
	}
	else
	{
		// shift left

		// move the bulbs
		for (byte i = _startbulb; i <= _endbulb + _step; i++)
		{
			if (_newcolour != NOCOLOUR)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(i-_step)->Colour());
			}
			if (_newbrightness != NOBRIGHTNESS)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(i-_step)->Brightness());
			}
			_string->GetBulb(i)->Display();
		}

		// fill in the gaps with the new colour/brightness if it was specified
		for (byte i = _endbulb + _step + 1; i <= _endbulb; i++)
		{
			if (_newcolour == NOCOLOUR)
			{
				// dont change the colour
			}
			else if (_newcolour == RANDOMALLONECOLOUR)
			{
				// set it to our random colour
				_string->GetBulb(i)->SetColour(_randomcolour);
			}
			else if (_newcolour == RANDOMCOLOUR)
			{
				// set it to a new random colour
				_string->GetBulb(i)->SetColour(Bulb::RandomColour());
			}
			else if (_newcolour == RANDOMSTEPCOLOUR)
			{
				// set it to a random colour for this step
				_string->GetBulb(i)->SetColour(randomcolour);
			}
			else
			{
				_string->GetBulb(i)->SetColour(_newcolour);
			}
			if (_newbrightness == NOBRIGHTNESS)
			{
				// dont change the brightness
			}
			else if (_newbrightness == RANDOMALLONEBRIGHTNESS)
			{
				// set it to our random brightness
				_string->GetBulb(i)->SetBrightness(_randombrightness);
			}
			else if (_newbrightness == RANDOMBRIGHTNESS)
			{
				// set it to a new random brightness
				_string->GetBulb(i)->SetBrightness(Bulb::RandomBrightness());
			}
			else if (_newbrightness == RANDOMSTEPBRIGHTNESS)
			{
				// set it to a random brightness for this step
				_string->GetBulb(i)->SetBrightness(randombrightness);
			}
			else
			{
				_string->GetBulb(i)->SetBrightness(_newbrightness);
			}
			_string->GetBulb(i)->Display();
		}
	}

	// one less cycle left
	_left--;
}

// Create the RotateBulbs instruction
// Parameters: startbulb, endbulb, step, cycles, rotatecolour, rotatebrightness
void RotateBulbs::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("RotateBulbs::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("RotateBulbs::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("RotateBulbs::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] < -49 || args[2] > 49 || args[2] < -1 * (args[1] - args[0]) || args[2] > (args[1] - args[0])) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("RotateBulbs::Construct Invalid step amount %d.\n", args[2]);
			error(4);
		}
		if ((args[2] < -1 * (args[1] - args[0]) / 2 || args[2] > (args[1] - args[0]) / 2) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("RotateBulbs::Construct WARNING Innefficent step amount %d.\n", args[2]);
		}
		if ((args[3] < 1 || args[3] > 16000) && !LinkedListVar::IsVariable(args[3]))
		{
			printf("RotateBulbs::Construct Invalid cycles %d.\n", args[3]);
			error(4);
		}
		if (args[4] < 0 || args[4] > 1)
		{
			printf("RotateBulbs::Construct Invalid rotate colour flag %d.\n", args[4]);
			error(4);
		}
		if (args[5] < 0 || args[5] > 1)
		{
			printf("RotateBulbs::Construct Invalid rotate brightness flag %d.\n", args[5]);
			error(4);
		}
		if (args[4] == 0 && args[5] == 0)
		{
			printf("RotateBulbs::Construct rotate colour flag and rotate brightness flag are both off.\n");
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);
	_step = GetVarOrValue(args[2]);
	_left = GetVarOrValue(args[3]);
	_rotatecolour = (args[4] == 1);
	_rotatebrightness = (args[5] == 1);
}

// Check if the instruction is done
bool RotateBulbs::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Rotate the bulbs
void RotateBulbs::Execute()
{
	#ifdef PC
		printf("   Pin: %d - ROTATEBULBS %d-%d by %d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb, _step);
	#endif

	// if we are rotating to the right
	if(_step > 0)
	{
		// grab a copy of the overlap bulbs
		NonDisplayableBulb** ppndb = (NonDisplayableBulb**)malloc(sizeof(NonDisplayableBulb*) * _step);
		NonDisplayableBulb** ppndbcurrent = ppndb;
		for (byte i = _endbulb - _step + 1; i <= _endbulb; i++)
		{
			*ppndbcurrent = new NonDisplayableBulb();
			(*ppndbcurrent)->Construct(_string->GetBulb(i)->Colour(), _string->GetBulb(i)->Brightness());
			ppndbcurrent++;
		}

		// move the bulbs
		for (byte i = _endbulb; i >= _startbulb + _step; i--)
		{
			if (_rotatecolour)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(i - _step)->Colour());
			}
			if (_rotatebrightness)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(i - _step)->Brightness());
			}
			_string->GetBulb(i)->Display();
		}

		ppndbcurrent = ppndb;
		for (byte i = _startbulb; i < _startbulb + _step; i++)
		{
			if (_rotatecolour)
			{
				_string->GetBulb(i)->SetColour((*ppndbcurrent)->Colour());
			}
			if (_rotatebrightness)
			{
				_string->GetBulb(i)->SetBrightness((*ppndbcurrent)->Brightness());
			}
			_string->GetBulb(i)->Display();
			ppndbcurrent++;
		}

		// destroy the copy of the overlap bulbs
		ppndbcurrent = ppndb;
		for (byte i = _endbulb - _step + 1; i <= _endbulb; i++)
		{
			delete *ppndbcurrent;
			ppndbcurrent++;
		}
		free(ppndb);
	}
	else
	{
		// rotate to the left

		// grab a copy of the overlap bulbs
		NonDisplayableBulb** ppndb = (NonDisplayableBulb**)malloc(sizeof(NonDisplayableBulb*) * (_step * -1));
		NonDisplayableBulb** ppndbcurrent = ppndb;
		for (byte i = _startbulb; i < _startbulb - _step; i++)
		{
			*ppndbcurrent = new NonDisplayableBulb();
			(*ppndbcurrent)->Construct(_string->GetBulb(i)->Colour(), _string->GetBulb(i)->Brightness());
			ppndbcurrent++;
		}

		// move the bulbs
		for(byte i = _startbulb; i <= _endbulb + _step; i++)
		{
			if (_rotatecolour)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(i - _step)->Colour());
			}
			if (_rotatebrightness)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(i - _step)->Brightness());
			}
			_string->GetBulb(i)->Display();
		}

		ppndbcurrent = ppndb;
		for(byte i = _endbulb + _step + 1; i <= _endbulb; i++)
		{
			if (_rotatecolour)
			{
				_string->GetBulb(i)->SetColour((*ppndbcurrent)->Colour());
			}
			if (_rotatebrightness)
			{
				_string->GetBulb(i)->SetBrightness((*ppndbcurrent)->Brightness());
			}
			_string->GetBulb(i)->Display();
			ppndbcurrent++;
		}

		// destroy the copy of the overlap bulbs
		ppndbcurrent = ppndb;
		for (byte i = _startbulb; i < _startbulb - _step; i++)
		{
			delete *ppndbcurrent;
			ppndbcurrent++;
		}
		free(ppndb);
	}

	// this cycle is done
	_left--;
}

// Create the SetFadeColour instruction
// Parameters: startbulb, endbulb, startcolour, endcolour, cycles
void SetFadeColour::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("SetFadeColour::Construct Invalid start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("SetFadeColour::Construct Invalid end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1] && !(LinkedListVar::IsVariable(args[0]) || LinkedListVar::IsVariable(args[1])))
		{
			printf("SetFadeColour::Construct Invalid start bulb %d greater than end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] & 0xF000) > 0 && args[2] != RANDOMALLONECOLOUR && !LinkedListVar::IsVariable(args[2]))
		{
			printf("SetFadeColour::Construct Invalid start colour 0x%X.\n", args[2]);
			error(4);
		}
		if ((args[3] & 0xF000) > 0 && args[3] != RANDOMALLONECOLOUR && !LinkedListVar::IsVariable(args[3]))
		{
			printf("SetFadeColour::Construct Invalid end colour 0x%X.\n", args[3]);
			error(4);
		}
		if ((args[4] < 0 || args[4] > 255) && !LinkedListVar::IsVariable(args[4]) && args[4] != NOBRIGHTNESS && args[4] != RANDOMALLONEBRIGHTNESS)
		{
			printf("SetFadeColour::Construct Invalid brightness %d.\n", args[4]);
			error(4);
		}
	#endif

	// save the parameters
	_startbulb = (byte)GetVarOrValue(args[0]);
	_endbulb = (byte)GetVarOrValue(args[1]);

	// handle random value support
	if (args[2] == RANDOMALLONECOLOUR)
	{
		// allocate a random colour
		_startcolour = Bulb::RandomColour();
	}
	else
	{
		_startcolour = GetVarOrValue(args[2]);
	}
	if (args[3] == RANDOMALLONECOLOUR)
	{
		// allocate a random colour
		_endcolour = Bulb::RandomColour();
	}
	else
	{
		_endcolour = GetVarOrValue(args[3]);
	}
	if (args[4] == RANDOMALLONEBRIGHTNESS)
	{
		// allocate a random brightness
		_brightness = Bulb::RandomBrightness();
	}
	else
	{
		_brightness = (byte)GetVarOrValue(args[4]);
	}
}

// Check if the instruction is done
bool SetFadeColour::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Set the bulb colour fading from one colour to another
void SetFadeColour::Execute()
{
	#ifdef PC
		printf("   Pin: %d - SETFADECOLOUR %d-%d.\n", _string->GetBulb(0)->Pin(), _startbulb, _endbulb);
	#endif

	// break down the start colour components
	float startred = (float)((_startcolour & 0xF00) >> 8);
	float startgreen = (float)((_startcolour & 0x0F0) >> 4);
	float startblue = (float)((_startcolour & 0x00F));

	// break down the end colour components
	float endred = (float)((_endcolour & 0xF00) >> 8);
	float endgreen = (float)((_endcolour & 0x0F0) >> 4);
	float endblue = (float)((_endcolour & 0x00F));

	// initialise the current colour
	float red = startred;
	float green = startgreen;
	float blue = startblue;

	// for each bulb in range
	for (byte i = _startbulb; i <= _endbulb; i++)
	{
		// work out the 12 bit colour
		short colour = (((int)red) << 8) + (((int)green) << 4) + (int)blue;

		// set the bulb colour
		_string->GetBulb(i)->SetColour(colour);

		// set the bulb brightness if one was specified
		if (_brightness != NOBRIGHTNESS)
		{
			_string->GetBulb(i)->SetBrightness(_brightness);
		}

		// send the commmand to the bulb
		_string->GetBulb(i)->Display();

		// work out the next colour
		red = red + (endred - startred)/(float)(_endbulb - _startbulb);
		blue = blue + (endblue - startblue)/(float)(_endbulb - _startbulb);
		green = green + (endgreen - startgreen)/(float)(_endbulb - _startbulb);
	}
}

// Create the CopyBulbs instruction
// Parameters: sourcestartbulb, sourceendbulb, targetstartbulb, targetendbulb, copycolour, copybrightness
void CopyBulbs::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 49) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("CopyBulbs::Construct Invalid source start bulb %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0 || args[1] > 49) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("CopyBulbs::Construct Invalid source end bulb %d.\n", args[1]);
			error(4);
		}
		if (args[0] > args[1])
		{
			printf("CopyBulbs::Construct Invalid source start bulb %d greater than source end bulb %d.\n", args[0], args[1]);
			error(4);
		}
		if ((args[2] < 0 || args[2] > 49) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("CopyBulbs::Construct Invalid target start bulb %d.\n", args[2]);
			error(4);
		}
		if ((args[3] < 0 || args[3] > 49) && !LinkedListVar::IsVariable(args[3]))
		{
			printf("CopyBulbs::Construct Invalid target end bulb %d.\n", args[3]);
			error(4);
		}
		if (args[4] < 0 || args[4] > 1)
		{
			printf("CopyBulbs::Construct Invalid copy colour flag %d.\n", args[4]);
			error(4);
		}
		if (args[5] < 0 || args[5] > 1)
		{
			printf("CopyBulbs::Construct Invalid copy brightness flag %d.\n", args[5]);
			error(4);
		}
		if (args[4] == 0 && args[5] == 0)
		{
			printf("CopyBulbs::Construct copy colour flag and copy brightness flag are both off.\n");
			error(4);
		}
	#endif

	// save the parameters
	_sourcestartbulb = (byte)GetVarOrValue(args[0]);
	_sourceendbulb = (byte)GetVarOrValue(args[1]);
	_targetstartbulb = (byte)GetVarOrValue(args[2]);
	_targetendbulb = (byte)GetVarOrValue(args[3]);
	_copycolour = (args[4] == 1);
	_copybrightness = (args[5] == 1);
}

// Check if the instruction is done
bool CopyBulbs::Done() const
{
	// This instruction only runs once
	return TRUE;
}

// Shift the bulbs replacing the gaps with a given colour
void CopyBulbs::Execute()
{
	#ifdef PC
		printf("   Pin: %d - COPYBULBS from %d-%d to %d-%d.\n", _string->GetBulb(0)->Pin(), _sourcestartbulb, _sourceendbulb, _targetstartbulb, _targetendbulb);
	#endif

	// if we are to reverse the bulbs
	if (_targetendbulb < _targetstartbulb)
	{
		// reversing

		// start with the last source bulb
		byte source = _sourceendbulb;

		// for each target bulb
		for (byte i = _targetstartbulb; i <= _targetendbulb; i++)
		{
			// copy the bulb
			if (_copycolour)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(source)->Colour());
			}
			if (_copybrightness)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(source)->Brightness());
			}
			_string->GetBulb(i)->Display();

			// look at the next source bulb
			source--;

			// if we have run out of source bulbs start again from the end
			if (source < _sourcestartbulb)
			{
				source = _sourceendbulb;
			}
		}
	}
	else
	{
		// copying

		// start with the first source bulb
		byte source = _sourcestartbulb;

		// for each target bulb
		for (byte i = _targetstartbulb; i <= _targetendbulb; i++)
		{
			// copy the bulb
			if (_copycolour)
			{
				_string->GetBulb(i)->SetColour(_string->GetBulb(source)->Colour());
			}
			if (_copybrightness)
			{
				_string->GetBulb(i)->SetBrightness(_string->GetBulb(source)->Brightness());
			}
			_string->GetBulb(i)->Display();

			// look at the next source bulb
			source++;

			// if we have run out of source bulbs start again from the beginning
			if (source > _sourceendbulb)
			{
				source = _sourcestartbulb;
			}
		}
	}
}

// Check if the instruction is done
bool Loop::Done() const
{
	// This instruction only runs once
	// maybe I should return a different answer if this has a dereference??????
	return TRUE;
}

void Loop::Setup(LightsString* string, short args[])
{
		// save the parameters
		_howfar = args[0];
		_left = GetVarOrValue(args[1]);
		_id = args[2];
	_ls = string;
	_loop = NULL;

		#ifdef PC
			printf("MEM, ALLOC, %ld, Loop %d.\n", this, args[2]);
		#endif
}

// Create the Loop instruction
// Parameters: shortstojumpback, timestoloop, ipofthisinstruction
void Loop::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if (args[0] < 0)
		{
			printf("Loop::Construct Invalid instructions to jump back %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < 0) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("Loop::Construct Invalid times to loop %d.\n", args[1]);
			error(4);
		}
	#endif

	_id = -1;
	_howfar = -1;
	_left = -1;

	// see if this loop is already in our active list
	_loop = string->GetLoop(args[2]);

	// if it is not there or we found ourselves
	if (_loop == NULL || _loop == this)
	{
		_loop = new Loop();
		_loop->Setup(string, args);

		string->AddLoop(_loop);

		#ifdef PC
			printf("MEM, ALLOC, %ld, Loop %d ... derferenced to %ld.\n", this, args[2], _loop);
		#endif
	}
	else
	{
		#ifdef PC
			printf("MEM, ALLOC, %ld, Loop %d ... derferenced to %ld.\n", this, args[2], _loop);
		#endif
	}

	// remember the lights string that owns us
	_ls = string;
}

// execute the instruction
void Loop::Execute()
{
	// if there is no instruction to delegate to
	if (_loop == NULL)
	{
		// if we have finished
		if (_left < 1)
		{
			#ifdef PC
				printf("   Pin: %d - LOOP %d done.\n", _ls->GetBulb(0)->Pin(), _id);
			#endif

			// we are done
			_ls->LoopDone(_id);
		}
		else
		{
			#ifdef PC
				printf("   Pin: %d - LOOP %d jumping (%d left).\n", _ls->GetBulb(0)->Pin(), _id, _left-1);
			#endif

			// we have completed one more loop
			_left--;

			// jump back by adjusting the instruction pointer
			_ls->AdjustIP(_howfar);
		}
	}
	else
	{
		// we have a delegate so call it instead
		_loop->Execute();

		// if it removed itself from the loops
		if(_ls->GetLoop(_loop->Id()) == NULL)
		{
			#ifdef PC
				printf("MEM, DEALLOC, %ld, Loop %d\n", _loop, _loop->Id());
			#endif

			// we can safely destroy it
			delete _loop;
			_loop = NULL;
		}
	}
}

// Create the DebugBreak instruction
// Parameters: cycles, breakoneverycycle
void DebugBreakI::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if ((args[0] < 0 || args[0] > 16000) && !LinkedListVar::IsVariable(args[0]))
		{
			printf("DebugBreak::Construct Invalid cycles %d.\n", args[0]);
			error(4);
		}
		if (args[1] < 0 || args[1] > 1)
		{
			printf("DebugBreak::Construct Invalid break on every cycle flag %d.\n", args[1]);
			error(4);
		}
	#endif

	// save the parameters
	_left = GetVarOrValue(args[0]);
	_breakoneach = (args[1] == 1);
}

// Check if the instruction is done
bool DebugBreakI::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Execute the instruction
void DebugBreakI::Execute()
{
	// should we break?
	if (_left <= 1 || _breakoneach)
	{
		#ifdef PC
			printf("   Pin: %d - DEBUGBREAK breaking.\n", _string->GetBulb(0)->Pin());
			_string->Break();
		#endif
	}
	else
	{
		#ifdef PC
			printf("   Pin: %d - DEBUGBREAK skipping.\n", _string->GetBulb(0)->Pin());
		#endif
	}

	_left--;
}

// Create the SetVariable instruction
// Parameters: variable, value, cycles, setoneachcycle
void SetVariable::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if (args[0] < -16199 || args[0] > -16100)
		{
			printf("SetVariable::Construct Invalid variable %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < -16000 || args[1] > 16000) && !LinkedListVar::IsVariable(args[1]) && args[1] != RANDOMBULB && args[1] != RANDOMCOLOUR && args[1] != RANDOMBRIGHTNESS && args[1] != NOCOLOUR && args[1] != NOBRIGHTNESS)
		{
			printf("SetVariable::Construct Invalid set variable value %d.\n", args[1]);
			error(4);
		}
		if ((args[2] < 0 || args[2] > 16000) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("SetVariable::Construct Invalid cycles %d.\n", args[2]);
			error(4);
		}
		if (args[3] < 0 || args[3] > 1)
		{
			printf("SetVariable::Construct Invalid set on each cycle flag %d.\n", args[3]);
			error(4);
		}
	#endif

	// save the parameters
	_var = args[0];
	_value = GetVarOrValue(args[1]);
	_left = GetVarOrValue(args[2]);
	_setoneach = (args[3] == 1);
}

// Check if the instruction is done
bool SetVariable::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Execute the instruction
void SetVariable::Execute()
{
	if (_left <= 1 || _setoneach)
	{
		short v;
		// handle special values
		if (_value == RANDOMBULB)
		{
			v = Bulb::RandomBulb();
		}
		else if(_value == RANDOMCOLOUR)
		{
			v = Bulb::RandomColour();
		}
		else if(_value == RANDOMBRIGHTNESS)
		{
			v = Bulb::RandomBrightness();
		}
		else
		{
			// save the value given
			v = _value;
		}
		#ifdef PC
			printf("   Pin: %d - SETVARIABLE %d=%d.\n", _string->GetBulb(0)->Pin(), _var, v);
		#endif

		// now set the variable
		SetVar(_var, v);
	}
	else
	{
		#ifdef PC
			printf("   Pin: %d - SETVARIABLE %d skipping.\n", _string->GetBulb(0)->Pin(), _var);
		#endif
	}

	_left--;
}

// Create the AdjustVariable instruction
// Parameters: variable, amount, cycles, adjustoneachcycle
void AdjustVariable::Construct(LightsString* string, short args[])
{
	BaseConstruct(string, args);

	#ifdef PC
		// check the parameters
		if (args[0] < -16199 || args[0] > -16100)
		{
			printf("AdjustVariable::Construct Invalid variable %d.\n", args[0]);
			error(4);
		}
		if ((args[1] < -16000 || args[1] > 16000) && !LinkedListVar::IsVariable(args[1]))
		{
			printf("AdjustVariable::Construct Invalid adjust variable value %d.\n", args[1]);
			error(4);
		}
		if ((args[2] < 0 || args[2] > 16000) && !LinkedListVar::IsVariable(args[2]))
		{
			printf("AdjustVariable::Construct Invalid cycles %d.\n", args[2]);
			error(4);
		}
		if (args[3] < 0 || args[3] > 1)
		{
			printf("AdjustVariable::Construct Invalid adjust on each cycle flag %d.\n", args[3]);
			error(4);
		}
	#endif

	// save the parameters
	_var = args[0];
	_amount = GetVarOrValue(args[1]);
	_left = GetVarOrValue(args[2]);
	_adjustoneach = (args[3] == 1);
}

// Check if the instruction is done
bool AdjustVariable::Done() const
{
	// if left has reached zero
	if (_left < 1)
	{
		// we are done
		return TRUE;
	}
	else
	{
		// we are not done
		return FALSE;
	}
}

// Execute the instruction
void AdjustVariable::Execute()
{
	// decide if we should adjust this time
	if (_left <= 1 || _adjustoneach)
	{
		#ifdef PC
			printf("   Pin: %d - ADJUSTVARIABLE %d by %d.\n", _string->GetBulb(0)->Pin(), _var, _amount);

			int curr = GetVarOrValue(_var);
			curr = curr + _amount;

			if (curr < -16000 || curr > 16000)
			{
				printf("AdjustVariable::Execute Adjusting variable %d by %d leads to invalid value %d.\n", _var, _amount, curr);
				error(4);
			}
		#endif

		// do the adjustment
		SetVar(_var, GetVarOrValue(_var) + _amount);
	}
	else
	{
		#ifdef PC
			printf("   Pin: %d - ADJUSTVARIABLE %d skipping.\n", _string->GetBulb(0)->Pin(), _var);
		#endif
	}

	// decrement cycles
	_left--;
}
