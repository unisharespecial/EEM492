#include "global.h"
#include "LinkedListVar.h"

#ifdef PC
	#include<stdio.h>
#endif

// Create the linked list
void LinkedListVar::Construct()
{
	// initialise the values
	_head = NULL;    
}

// variables lie between -16100 and -16199
bool LinkedListVar::IsVariable(short var)
{
	return (var > -16200 && var <= -16100);
}

// We dont need this so commented out to save space
// Destroy the linked list
//LinkedListVar::~LinkedListVar()
//{
//  // deallocate memory space of each node in the list.
//  for (node* t = _head; t != NULL; _head = t)
//  {
//    t = _head->next; free (_head);
//  }
//}

// set a variable
void LinkedListVar::Set(short var, short val)
{
	node* v = Find(var);

	if (v == NULL)
	{
		// allocate memory for the node
		v = (node*) malloc (sizeof (node));
		v->_var = var;
		v->_val = val;
		v->next = _head;
		_head = v;
	}
	else
	{
		v->_val = val;
	}
}

// get a variable
short LinkedListVar::Get(short var)
{
	node* v = Find(var);

	if (v == NULL)
	{
		#ifdef PC
			printf("Access to undefined variable %d.\n", var);
		#endif
		return 0;
	}
	else
	{
		return v->_val;
	}
}

// find a variable
LinkedListVar::node* LinkedListVar::Find(short var)
{
	// start at the head
	node* curr = _head;

	// go through each node
	while (curr != NULL)
	{
		// if we found it return it
		if (curr->_var == var)
		{
			return curr;
		}

		curr = curr->next;
	}

	return NULL;
}

