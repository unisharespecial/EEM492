
#ifndef _LINKEDLIST_H

#define _LINKEDLIST_H

#ifndef PC
	// include necessary header for libraries.
	#include <WProgram.h>
#endif

class Instruction; // forward reference the class we hold in our list

#include "Instruction.h"

// the definition of the stack class.
class LinkedList
{  
private:

	// a linked list node
	typedef struct node
	{
		Instruction* item; // the item in this node
		node* next; // pointer to the next node
	} node;

	node* _current; // current node when iterating
	node* _head; // head node
	node* _tail; // last node
	short _size; // nodes in the list

   public:

	#ifdef PC
		LinkedList() {};	
	#endif
      
	void Construct();
	
	//~LinkedList();
	void addend(Instruction* i);
	Instruction* head();
	Instruction* next();
	void remove(Instruction* i);
	short count () const;
};

#endif // _LINKEDLIST_H
