#ifdef PC
	#include <stdio.h>
	#include <Windows.h>
#endif

#include "global.h"
#include "cppfix.h"

// This function is called when an error occurs.
void error(int i)
{
#ifdef PC
	printf("ERROR %d!!!!!!\n", i);

	// hang
	while(true)
	{
		Sleep(1000);
	}
#else
	while(true)
	{
		for (int j = 0; j < i; j++)
		{
			// flash the 11 pin
			digitalWrite(11, 1);
			delay(500);
			digitalWrite(11, 0);
			delay(500);
		}
		delay(3000);
	}
#endif
}

#ifndef PC

// need to provide my own new
void * operator new(size_t size)
{
	// allocate the memory
	void* p = malloc(size);

	// if it did not work
	if (p == NULL)
	{
		// report an error
		error(1);
	}

	// return the memory
	return p;
}


// need to provide my own delete
void operator delete(void * ptr)
{
	// release the memory
	if (ptr != NULL)
	{
		free(ptr);
	}
}
#endif