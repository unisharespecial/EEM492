#ifndef _CPPFIX_H

#define _CPPFIX_H

#ifndef PC
	// include necessary header for libraries.
	#include <WProgram.h>

	void * operator new(size_t size);
	void operator delete(void * ptr);
#endif

	void error(int i);

#endif // _CPPFIX_H
