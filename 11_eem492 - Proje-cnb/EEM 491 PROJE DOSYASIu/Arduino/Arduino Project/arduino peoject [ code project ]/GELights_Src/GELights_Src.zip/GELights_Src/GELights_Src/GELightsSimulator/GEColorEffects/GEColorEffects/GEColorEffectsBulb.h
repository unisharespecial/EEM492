#ifndef _GECOLOREFFECTSBULB_H

#define _GECOLOREFFECTSBULB_H

#include "global.h"

#ifdef PC
	#include <windows.h>
#else
	// include necessary header for libraries.
	#include <WProgram.h>
	#include <avr/pgmspace.h>

	#define FALSE 0
	#define TRUE 1

	// 6 works on pro
	//#define MICROSECONDSWAITDIFF 6
	//#define MICROSECONDSWAITSAME 6

	// 2560
	#define MICROSECONDSWAITDIFF 4
	#define MICROSECONDSWAITSAME 3

	extern byte lastBit; // remembers the last value sent
#endif

#define PINADJUST 3 // offset from 0 for the output pin to use - 3 is used as pins 1 & 2 have resistors on them

// preset random brightnesses
static const byte _brightnesses[]
	#ifndef PC
		PROGMEM
	#endif
	= {  0, 50, 100, 150, 200 };

// preset random colours
static const short _colours[]
	#ifndef PC
		PROGMEM
	#endif
	//  red    green  blue   yellow orange violet white  magenta cyan
	= { 0xF00, 0x0F0, 0x00F, 0xF80, 0xF20, 0x80F, 0xDDD, 0xF0F, 0x0FF };

class NonDisplayableBulb
{
	protected:
		short _colour; // the bulbs colour
		byte _brightness; // the bulbs brightness

	public:
		#ifdef PC
			NonDisplayableBulb() {};
		#endif
		void Construct(short colour, byte brightness);
		byte Brightness();
		void SetBrightness(byte brightness);
		short Colour();
	        void SetColour(short colourrgb);
		void SetChanged();
		void ClearChanged();
		bool IsChanged();
};

// A bulb
class Bulb : public NonDisplayableBulb
{
	private:
		byte _pin; // output pin for this bulb
		byte _address; // the bulbs address
		void OutputOne();
		void OutputZero();
		#ifdef PC
			unsigned char _output; // a byte to be sent
			short _used; // number of bits used in the byte
			char _outputstr[36]; // a message to be sent
			short _strused; // number of characters used in the message
			HWND GetSimulatorWindow();
			void Output(bool bit);
		#endif

	public:
		#ifdef PC
			Bulb() {};
		#endif
		void Construct(byte pin, byte address, short colour, byte brightness);
		void Display();
		static byte RandomBrightness();
		static short RandomColour();
		static byte RandomBulb();
		byte Pin() { return _pin; };
};

#endif // _GECOLOREFFECTSBULB_H
