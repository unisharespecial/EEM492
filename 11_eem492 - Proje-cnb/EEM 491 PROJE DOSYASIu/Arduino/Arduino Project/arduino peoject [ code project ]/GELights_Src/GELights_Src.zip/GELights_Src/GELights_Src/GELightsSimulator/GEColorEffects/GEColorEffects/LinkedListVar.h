
#ifndef _LINKEDLISTVAR_H

#define _LINKEDLISTVAR_H

#ifdef PC
	#include <windows.h>
#else
	// include necessary header for libraries.
	#include <WProgram.h>
#endif

// the definition of the stack class.
class LinkedListVar
{  
private:
	// a linked list node
	typedef struct node
	{
		short _var;
		short _val;
		node* next; // pointer to the next node
	} node;
	node* _head; // head node
	node* Find(short var);

   public:
	#ifdef PC
		LinkedListVar() {};	
	#endif
	void Construct();
	//~LinkedListVar();
	void Set(short var, short val);
	short Get(short var);
	static bool IsVariable(short var);
};

#endif // _LINKEDLISTVAR_H
