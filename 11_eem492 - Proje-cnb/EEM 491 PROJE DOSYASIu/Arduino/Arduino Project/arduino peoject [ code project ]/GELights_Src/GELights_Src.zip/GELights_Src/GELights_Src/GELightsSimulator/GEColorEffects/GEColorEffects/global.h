#ifndef _GLOBAL_H

#define _GLOBAL_H

// un-comment this to turn on debug printing to the screen or to the serial port. This will interfere with the lights but will let you troubleshoot the program logic.
//#define DEBUG 1

#endif // _GLOBAL_H
