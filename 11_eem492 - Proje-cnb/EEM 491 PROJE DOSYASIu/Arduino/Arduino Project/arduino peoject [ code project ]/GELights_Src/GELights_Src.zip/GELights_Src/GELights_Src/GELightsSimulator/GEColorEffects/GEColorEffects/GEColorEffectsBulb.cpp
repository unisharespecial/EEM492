#ifdef PC
	#define _CRT_SECURE_NO_WARNINGS 1
	#include <stdio.h>
	#include <tchar.h>
	#include <stdlib.h>
	#include "cppfix.h"
#endif

#include "global.h"
#include "GEColorEffectsBulb.h"

// these make code readable but run faster
#define OUTPUTONE { OutputZero(); OutputZero(); OutputOne(); }
#define OUTPUTZERO { OutputZero(); OutputOne(); OutputOne(); }

// Get a random brightness
byte Bulb::RandomBrightness()
{
	// pick one the the available brightnesses
	#ifdef PC
		return _brightnesses[rand() % 5];
	#else
		return pgm_read_byte_near(_brightnesses + random(5));
	#endif
}

// Get a random bulb
byte Bulb::RandomBulb()
{
	#ifdef PC
		return (byte)(rand() % 50);
	#else
		return (byte)random(50);
	#endif
}

// Get a random colour
short Bulb::RandomColour()
{
	// pick one the the available colours
	#ifdef PC
		// return the number of parameters for the provided command type
		return _colours[rand() % 9];
	#else
		return pgm_read_word_near(_colours + random(9));
	#endif
}

// create a bulb
void Bulb::Construct(byte pin, byte address, short colour, byte brightness)
{
	#ifdef PC
		if ((colour & 0xF000) > 0)
		{
			printf("Bulb::Construct Invalid colour 0x%X.\n", colour);
			error(6);
		}
	#endif

	// save the values
	_pin = pin;
	_address = address;
	_colour = colour;
	_brightness = brightness;

	// creating a bulb is a change so set the changed flag
	SetChanged();

	#ifdef PC
		// initialise the fields used to send the result to the simulator
		_output = 0;
		_used = 0;
		_strused = 0;
		memset(&_outputstr[0], 0, 36);
	#endif
}

// create a bulb
void NonDisplayableBulb::Construct(short colour, byte brightness)
{
	// save the values
	_colour = colour;
	_brightness = brightness;

	// dont need to set changed as these bulbs can't be displayed
}

// Get the bulb brightness
byte NonDisplayableBulb::Brightness()
{
	return _brightness;
}

// Set the bulb brightness
void NonDisplayableBulb::SetBrightness(byte brightness)
{
	byte b = brightness;

	// if less than zero make it zero
	if (brightness < 0)
	{
		b = 0;
	}
	// if greater than maximum make it the maximum
	else if (brightness > 0xCC)
	{
		// 0xCC is the highest value allowed
		b = 0xCC;
	}

	if (b == _brightness)
	{
		return;
	}

	// save the new brightness
	_brightness = b;

	// it has been changed
	SetChanged();
}

// Get the bulb colour
short NonDisplayableBulb::Colour()
{
	// return the colour without the changed flag bit
	return (_colour & 0x7FFF);
}

// set the bulb colour
void NonDisplayableBulb::SetColour(short colour)
{
	#ifdef PC
		if ((colour & 0xF000) > 0)
		{
			printf("NonDisplayableBulb::SetColour Invalid colour 0x%X.\n", colour);
			error(2);
		}
	#endif

	// if the colour has changed
	if (Colour() != colour)
	{
		// save the new colour
		_colour = colour;

		// flag the bulb as changed
		SetChanged();
	}
}

// flag a bulb as having changed
void NonDisplayableBulb::SetChanged()
{
	// set the high bit in the colour
	_colour = _colour | 0x8000;
}

// flag a bulb as not having changed
void NonDisplayableBulb::ClearChanged()
{
	// clear the high bit in the colour
	_colour = _colour & 0x7FFF;
}

// check the bulb changed flag
bool NonDisplayableBulb::IsChanged()
{
	// check the high bit
	return ((_colour & 0x8000) > 0);
}

#ifdef PC
	// Find the simulator to send messages to
	HWND Bulb::GetSimulatorWindow()
	{
		static HWND __hwnd = NULL; // cache the value to speed this up

		// if we have a cached value
		if (__hwnd != NULL)
		{
			// check it is valid
			if (IsWindow(__hwnd))
			{
				// return it
				return __hwnd;
			}

			// clear the invalid value
			__hwnd = NULL;
		}

		// try to find the window based on its name
		__hwnd = FindWindow(NULL, _T("GE Color Effects Simulator"));

		// return the value (it could be null)
		return __hwnd;
	}
#endif

// Write a zero
inline void Bulb::OutputZero()
{
	#ifdef PC
		// call the old slow function as there is lots of work to do
		Output(false);
	#else

		// set the pin to zero
		digitalWrite(_pin,0);

		if (lastBit == 1)
		{
			//The pulse should be 10 uS long, but I had to hand tune the delays. They work for me
			delayMicroseconds(MICROSECONDSWAITDIFF);
		}
		else
		{
			delayMicroseconds(MICROSECONDSWAITSAME);
		}

		lastBit = 0;
	#endif
}

// write a one
inline void Bulb::OutputOne()
{
	#ifdef PC
		// call the old slow function as there is lots of work to do
		Output(true);
	#else

		// set the pin to one
		digitalWrite(_pin,1);

		if (lastBit == 0)
		{
			//The pulse should be 10 uS long, but I had to hand tune the delays. They work for me
			delayMicroseconds(MICROSECONDSWAITDIFF);
		}
		else
		{
			delayMicroseconds(MICROSECONDSWAITSAME);
		}

		lastBit = 1;
	#endif
}

#ifdef PC
	// send a bit out
	void Bulb::Output(bool bit)
	{
		// first we need to gather the bits into bytes

		// add it to our byte
		_output = _output + (((int)bit) << (7 - _used));

		// up our used count
		_used ++;

		// if our byte is full
		if (_used == 8)
		{
			// convert it into a 3 character number
			char num[6];
			sprintf(&num[0], "%03d", _output);

			// add it to our message
			strcat(_outputstr, num);

			// reset our byte
			_used = 0;
			_output = 0;

			// up our used count of bytes in our message
			_strused ++;

			// if our message is full
			if (_strused == 11)
			{
				// get the window to send the message to
				HWND hwnd = GetSimulatorWindow();

				// if we found the window
				if (hwnd != NULL)
				{
					// open the clip board
					if (OpenClipboard(NULL))
					{
						// clear the clipboard
						EmptyClipboard();

						// prepare our data
						HGLOBAL hClipboardData;
						hClipboardData = GlobalAlloc(GMEM_DDESHARE, 36);
						char * pchData;
						pchData = (char*)GlobalLock(hClipboardData);
						strcpy(pchData, _outputstr);
						GlobalUnlock(hClipboardData);

						// copy it to the clipboard
						SetClipboardData(CF_TEXT,hClipboardData);

						// close the clipboard
						CloseClipboard();

						// send a message to the simulator to tell it there is data in the clipboard and wait for it to grab it ... WPARAM specifies which pin the light is on ... this allows for multiple light strings
						SendMessage(hwnd, 1024, _pin - PINADJUST, 0);
					}
				}

				// reset our message
				_strused = 0;
				memset(&_outputstr[0], 0, 36);
			}
		}
	}
#endif

// Display the bulb
void Bulb::Display()
{
	// if the bulb hasnt changed then dont send anything!
	if (!IsChanged())
	{
		return;
	}

#ifdef PC
	// check our pin is valid
	if (_pin < 0)
	{
		// this is a problem
		printf("Error - attempting to display a bulb with no pin set!!!");
		error(5);
	}
#endif

	// we are displaying it so clear the changed flag
	ClearChanged();

	#ifdef DEBUG
		#ifdef PC
			printf("Sending a bulb. ");
			printf("Pin %d ", _pin);
			printf("Address %d ", _address);
			printf("Brightness %d ", _brightness);
			printf("Red %d ", ((_colour & 0xF00) >> 8));
			printf("Green  %d ", ((_colour & 0xF0) >> 4));
			printf("Blue  %d\n", (_colour & 0x0F));
		#else
			Serial.print("Sending a bulb. ");
			Serial.print(_pin, DEC);
			Serial.print(", ");
			Serial.print(_address, DEC);
			Serial.print(", ");
			Serial.print(_brightness, DEC);
			Serial.print(", ");
			Serial.print(((_colour & 0xF00) >> 8), DEC);
			Serial.print(", ");
			Serial.print(((_colour & 0xF0) >> 4), DEC);
			Serial.print(", ");
			Serial.println((_colour & 0x0F), DEC);
		#endif
	#endif

	// Must have at least 3 zeroes before the bulb with recognise a new message
	OutputZero();
	OutputZero();
	OutputZero();

	// start bit
	OutputOne();

	// send the bulb address 0-49 or 63
	if (_address & 0x20) OUTPUTONE else OUTPUTZERO
	if (_address & 0x10) OUTPUTONE else OUTPUTZERO
	if (_address & 0x08) OUTPUTONE else OUTPUTZERO
	if (_address & 0x04) OUTPUTONE else OUTPUTZERO
	if (_address & 0x02) OUTPUTONE else OUTPUTZERO
	if (_address & 0x01) OUTPUTONE else OUTPUTZERO

	// send the brightness 0-255
	if (_brightness & 0x80) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x40) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x20) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x10) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x08) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x04) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x02) OUTPUTONE else OUTPUTZERO
	if (_brightness & 0x01) OUTPUTONE else OUTPUTZERO

	// send blue
	if (_colour & 0x0008) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0004) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0002) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0001) OUTPUTONE else OUTPUTZERO

	// send green
	if (_colour & 0x0080) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0040) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0020) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0010) OUTPUTONE else OUTPUTZERO

	// send red
	if (_colour & 0x0800) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0400) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0200) OUTPUTONE else OUTPUTZERO
	if (_colour & 0x0100) OUTPUTONE else OUTPUTZERO

	// leave it at zero
	OutputZero();

	#ifdef PC
		// only required on PC to round out to 11 bytes exactly
		OutputZero();
		OutputZero();
		OutputZero();
		OutputZero();
		OutputZero();
	#endif
}

