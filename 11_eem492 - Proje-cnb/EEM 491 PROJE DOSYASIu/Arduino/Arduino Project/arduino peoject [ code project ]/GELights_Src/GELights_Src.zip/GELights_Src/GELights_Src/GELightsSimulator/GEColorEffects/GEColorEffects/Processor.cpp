#include "global.h"
#include "Processor.h"

#ifdef PC
#include <stdio.h>
#endif

extern short cycleinterval; // access a variable declared in GEColorEffects.cpp

// Run the program
void Processor::Run()
{
	#ifndef PC
		// set the 13 pin as an output pin - we flash this each time the program goes through a cycle
		pinMode(13, OUTPUT);
		byte exec = 0;
	#else
		int cycle = 0;
	#endif


	// forever
	while(true)
	{
		#ifdef PC
			cycle++;
			printf("Cycle %d ", cycle);
		#else
			// flash the 13 pin
			digitalWrite(13, exec);
			exec++;
			if (exec > 1)
			{
				exec = 0;
			}
		#endif

		// go through all the strings
		for (byte i = 0; i < MAXSTRINGS; i++)
		{
			// if there is a program there
			if (_strings[i]->IsValid())
			{
				// if there are no instructions in the queue to execute or at least all the donothings are done
				if (_strings[i]->Executing()->count() == 0 || _strings[i]->AllDone())
				{
					// load some instructions
					_strings[i]->LoadInstructions();
				}
			}
		}

		#ifdef PC
			printf("\n");
		#endif

		// go through all the strings
		for (byte i = 0; i < MAXSTRINGS; i++)
		{
			// if there is a program there
			if (_strings[i]->IsValid())
			{
				// execute a step
				_strings[i]->Execute();
			}
		}

		// debug progress statements
		#ifdef DEBUG
			#ifdef PC
				printf("End of cycle.\n");
				printf("Sleeping for %d\n", cycleinterval);
			#else
				Serial.print("End of cycle. Sleeping for ");
				Serial.println(cycleinterval, DEC);
			#endif
		#endif

		// sleep for our cycle interval
		#ifdef PC
			if (_break)
			{
				MessageBox(NULL, L"Debug Break", L"Debug Break", MB_OK);
				_break = false;
			}
			else
			{
				Sleep((DWORD)cycleinterval);
			}
		#else
			delay(cycleinterval);
		#endif
	}
}

// Dont need this as the processor is never destroyed
//Processor::~Processor()
//{
//	for (short i = 0; i < MAXSTRINGS; i++)
//	{
//		delete _string[i];
//	}
//}

// add a string of lights with a program
#ifdef PC
	void Processor::AddString(const byte pin, short* program)
#else
	void Processor::AddString(const byte pin, prog_int16_t* program)
#endif
	{
		// create the lights string
		_strings[pin]->Construct(pin, program);
	}

// Create a processor
void Processor::Construct()
{
#ifdef PC
	_break = false;
#endif

	// create the strings but set them to invalid
	for (byte i = 0; i < MAXSTRINGS; i++)
	{
		#ifdef PC
			_strings[i] = new LightsString(this);
		#else
			_strings[i] = new LightsString();
		#endif
		_strings[i]->SetInvalid();
	}
}
