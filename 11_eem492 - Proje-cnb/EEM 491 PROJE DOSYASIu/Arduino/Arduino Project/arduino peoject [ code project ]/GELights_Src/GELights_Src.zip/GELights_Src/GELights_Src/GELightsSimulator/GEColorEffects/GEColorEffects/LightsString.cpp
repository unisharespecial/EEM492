#include "global.h"
#include "LightsString.h"
#include "cppfix.h"

#ifdef PC
	#include <stdio.h>
	#include "Processor.h"
#endif

// get the loop instruction from the open loops list
Loop* LightsString::GetLoop(short id)
{
	// start at the head
	Loop* curr = (Loop*)_loops->head();

	// while we are not at the end
	while(curr != NULL)
	{
		// if the id matches
		if(curr->Id() == id)
		{
			// return it
			return curr;
		}

		// get the next one
		curr = (Loop*)_loops->next();
	}

	// it is not in the list
	return NULL;
}

// adjust the instruction pointer by the given amount
void LightsString::AdjustIP(short howmuch)
{
	// adjust the instruction pointer
	_ip = _ip - howmuch;

	#ifdef PC
		// error checking only performed in the emulator
		if (_ip < 0)
		{
			error(10);
		}
	#endif
}

// do what we need to do when the loop is finished
void LightsString::LoopDone(short id)
{
	// get the loop instruction
	Loop* l = GetLoop(id);

	#ifdef PC
		// error checking only performed in the emulator
		if (l == NULL)
		{
			error(9);
		}
	#endif

	// remove it from the list
	_loops->remove(l);

// this needs testing ... meant to stop leakage of memory due to loops
// it may not work as i suspect every time I hit the loop instruction I create another loop instruction pointing back to the first ... need to do work to stop loop object proliferation ... this may explain my memory issue !!!
//TODO
//	#ifdef PC
//		printf("Destroying loop object %d at address %ld.\n", id, l);
//	#endif

//	delete l;
}

// adjust the pin from 0 to the first one we are actually using
inline byte LightsString::CorrectPin(const byte pin)
{
	return pin + PINADJUST;
}

// get a piece of data from the program array
#ifdef PC
	inline short LightsString::GetData(short* program, short offset)
	{
		return *(program+offset);
	}
#else
	inline short LightsString::GetData(prog_int16_t* program, short offset)
	{
		return pgm_read_word_near(program+offset);
	}
#endif

// get the next instruction from the program array
Instruction* LightsString::GetNextInstruction()
{
	// if the next instruction is -1 then we are done
	if (GetData(_program, _ip) < 0)
	{
		// no more instructions
		return NULL;
	}

	// get the instruction
	byte type = (byte)GetData(_program, _ip);

	// move to the next
	_ip++;

	// now grab each parameter
	short args[10]; // arguments for the instruction
	for(byte j = 0; j < Instruction::Parameters(type); j++)
	{
		args[j] = GetData(_program, _ip);
		_ip++;
	}

	Instruction* inst = NULL;

	// create the right instruction
	switch(type)
	{
	case 1:
		inst = new Pause();
		break;
	case 2:
		inst = new SetColour();
		break;
	case 3:
		inst = new SetAllBrightness();
		break;
	case 4:
		inst = new AdjustBrightness();
		break;
	case 5:
		inst = new AdjustAllBrightness();
		break;
	case 6:
		inst = new SetCycleInterval();
		break;
	case 7:
		inst = new AdjustCycleInterval();
		break;
	case 8:
		inst = new FadeColour();
		break;
	case 9:
		inst = new FadeBrightness();
		break;
	case 10:
		inst = new DoNothing();
		break;
	case 11:
		inst = new ShiftBulbs();
		break;
	case 12:
		inst = new RotateBulbs();
		break;
	case 13:
		inst = new SetFadeColour();
		break;
	case 14:
		inst = new CopyBulbs();
		break;
	case 15:
		// this is used as the id of the loop
		args[2] = _ip;
		inst = new Loop();

		// if it is not already in the list
//		if (GetLoop(_ip) == NULL)
//		{
//			// add it to the list
//			_loops->addend(inst);
//		}
		break;
	case 16:
		inst = new DebugBreakI();
		break;
	case 17:
		inst = new SetVariable();
		break;
	case 18:
		inst = new AdjustVariable();
		break;
	default:
		// unknown command
		#ifdef PC
			printf("Unknown command %d.\n", (int)type);
		#endif
		error(8);
		break;
	}

	if (inst != NULL)
	{
		// construct the instruction
		inst->Construct(this, args);
	}

	return inst;
}

// return the variable
short LightsString::GetVar(short var)
{
	return _vars->Get(var);
}

// save the variable
void LightsString::SetVar(short var, short val)
{
	_vars->Set(var, val);
}

// create a string of lights
#ifdef PC
	void LightsString::Construct(const byte pin, short* program)
#else
	void LightsString::Construct(const byte pin, prog_int16_t* program)
#endif
	{
		// make sure this is NULL
		_executing = NULL;

		#ifdef PC
			_processor = NULL;
		#endif

		// correct the pin number
		byte p = CorrectPin(pin);

		// start at the beginning
		_ip = 0;

		// remember the program we are running
		_program = program;

		#ifdef DEBUG
			#ifdef PC
				printf("About to check if we have any instructions.\n");
			#else
				Serial.println("About to check if we have any instructions.");
			#endif
		#endif

		// only create bulbs if we have a program
		if (GetNextInstruction() != NULL)
		{
			// reset the instruction pointer
			_ip = 0;

			#ifndef PC
				// set the pin as an output pin
				pinMode(p, OUTPUT);
			#endif

			#ifdef DEBUG
				#ifdef PC
					printf("About to create lists.\n");
				#else
					Serial.println("About to create lists.");
				#endif
			#endif

			// create the execution list
			_executing = new LinkedList();
			_executing->Construct();

			// create my list of open loops
			_loops = new LinkedList();
			_loops->Construct();

			_vars = new LinkedListVar();
			_vars->Construct();

			#ifdef DEBUG
				#ifdef PC
					printf("About to create bulbs.\n");
				#else
					Serial.println("About to create bulbs.");
				#endif
			#endif

			// create the bulbs and set them all to black to initialise them and allocate an address
			for(byte i = 0; i < 50; i++)
			{
				_bulbs[i] = new Bulb();
				_bulbs[i]->Construct(p, i, 0x000, 0xCC);
				_bulbs[i]->Display();
			}

			// create the special brighness broadcast bulb and set it to black and on
			_allbulbs = new Bulb();
			_allbulbs->Construct(p, 63, 0x000, 0xCC);

			#ifdef DEBUG
				#ifdef PC
					printf("Bulbs created.\n");
				#else
					Serial.println("Bulbs created.");
				#endif
			#endif
		}
		else
		{
			#ifdef DEBUG
				#ifdef PC
					printf("No instructions.\n");
				#else
					Serial.println("No instructions.");
				#endif
			#endif
		}
	}

// get a bulb
Bulb* LightsString::GetBulb(byte address)
{
	// check address is valid
	#ifdef PC
		if ((address < 0 || address > 49) && address != 63)
		{
			error(7);
		}
	#endif

	// if we are not valid then nothing to return
	if (!IsValid())
	{
		return NULL;
	}

	// if it is the broadcast bulb then return it
	if (address == 63)
	{
		return _allbulbs;
	}

	// otherwise return from the list
	return _bulbs[address];
}

// Get executing instructions
LinkedList* LightsString::Executing()
{
	// if we are not valid then nothing to return
	if (!IsValid())
	{
		return NULL;
	}

	return _executing;
}

// Dont need this as the lightstring is never destroyed
//LightsString::~LightsString()
//{
//	if (_executing != NULL)
//	{
//		Instruction* i;
//		while((i = _executing->head()) != NULL)
//		{
//			_executing.Remove(i);
//			delete i;
//		}
//	}
//	delete _executing;
//}

// Execute a cycle of the instructions in the executing queue
void LightsString::Execute()
{
	// if we are not valid then nothing to return
	if (!IsValid())
	{
		return;
	}

	// get the first instruction
	Instruction * inst = _executing->head();

	// while we have an instruction
	while(inst != NULL)
	{
		// execute it
		inst->Execute();

		// if it is complete
		if (inst->Done())
		{
			// remove it from the executing queue
			_executing->remove(inst);

			#ifdef PC
			if (inst->Type() == 15)
			{
				printf("MEM, DEALLOC, %ld, Loop (dereferenced)%d\n", inst, ((Loop*)inst)->Id());
			}
			#endif

			// dont destroy loops
///			if (inst->Type() != 15)
//			{
				// destroy it
				delete inst;
//			}
		}

		// get the next instruction
		inst = _executing->next();
	}
}

#ifdef PC
void LightsString::Break()
{
	_processor->Break();
}
#endif

// load the executing list with instructions
void LightsString::LoadInstructions()
{
	// if we are not valid then nothing to return
	if (!IsValid())
	{
		return;
	}

	Instruction* next; // next instruction in the program queue

	do
	{
		// get the next instruction
		next = GetNextInstruction();

		if (next == NULL)
		{
			// always end with a do nothing
			short args[1] = {1};
			next = new DoNothing();
			next->Construct(this, args);

			// start at the beginning next time
			_ip = 0;

			#ifdef PC
				printf("Pin:%d:Restarting ", _bulbs[0]->Pin());
			#endif
		}

		// add it to the executing queue
		_executing->addend(next);
	}
	// loop until we found a do nothing instruction or a loop ... at which point we should run a cycle
	while(next->Type() != 10 && next->Type() != 15);
}

void LightsString::AddLoop(Loop* loop)
{
	_loops->addend(loop);
}

// Check if all do nothing instructions in the executing list are done
bool LightsString::AllDone()
{
	// if we are not valid then nothing to return
	if (!IsValid())
	{
		return TRUE;
	}

	// get the head instruction
	Instruction* inst = _executing->head();

	// while we are not at the end of the list
	while(inst != NULL)
	{
		// if this is a donothing instruction and it is not done
		if ((inst->Type()) == 10 && (!inst->Done()))
		{
			// we are not all done
			return FALSE;
		}

		// get the next instruction
		inst = _executing->next();
	}

	// none were not done so we are all done
	return TRUE;
}