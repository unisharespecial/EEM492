#ifndef _PROCESSOR_H

#define _PROCESSOR_H

#ifndef PC
	// include necessary header for libraries.
	#include <WProgram.h>
	#include <avr/pgmspace.h>
#endif

#include "cppfix.h"
#include "LinkedList.h"
#include "Instruction.h"
#include "LightsString.h"

#define MAXSTRINGS 6 // this is the maximum number of strings we can support

class Processor
{
private:
	LightsString* _strings[MAXSTRINGS]; // collection of lights strings we are controlling
	#ifdef PC
		bool _break;
	#endif
	bool AllDone();
	void LoadInstructions();
	void Execute();

public:
	void Construct();
	//~Processor();
	void Run();
#ifdef PC
	void Break() {_break = true;};
	Processor() {};
	void AddString(const byte pin, short* program);
#else
	void AddString(const byte pin, prog_int16_t* program);
#endif
};

#endif // _PROCESSOR_H
