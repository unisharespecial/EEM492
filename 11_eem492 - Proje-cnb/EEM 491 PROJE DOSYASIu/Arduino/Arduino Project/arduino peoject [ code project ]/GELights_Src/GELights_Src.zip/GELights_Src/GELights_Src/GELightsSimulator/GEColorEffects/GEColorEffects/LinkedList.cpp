#include "global.h"
#include "LinkedList.h"

// Create the linked list
void LinkedList::Construct()
{
	// initialise the values
	_current = NULL;
	_head = NULL;
	_tail = NULL;
	_size = 0;
}

// We dont need this so commented out to save space
// Destroy the linked list
//LinkedList::~LinkedList()
//{
//  // deallocate memory space of each node in the list.
//  for (node* t = _head; t != NULL; _head = t)
//  {
//    t = _head->next; free (_head);
//  }
//  _size = 0;       // set the size of stack to zero.
//}

// add an item to the end of list
void LinkedList::addend(Instruction* i)
{
	// allocate memory for the node
	node* t = (node*) malloc (sizeof (node));

	// store the item to the new node.
	t->item = i;

	// it is at the end of the list
	t->next = NULL;

	// if this is the first item in the list
	if(_head == NULL)
	{
		// it is the head and tail
		_head = t;
		_tail = t;
	}
	else
	{
		// the tail item points to the new item
		_tail->next = t;

		// this is the new tail item
		_tail = t;
	}

	// list is one bigger now
	_size++;
}

// remove an item from the list
void LinkedList::remove(Instruction* i)
{
	node* iter = _head; // start at the begging
	node* prev = NULL; // track the prior item so we can fix it up

	// while we are not at the end of the list
	while (iter != NULL)
	{
		// if this item matches
		if (iter->item == i)
		{
			// if this is the head of the list
			if(iter == _head)
			{
				// set the head to the next item
				_head = iter->next;
			}
			else
				// not the head of the list
			{
				// point the previous item to the next item
				prev->next = iter->next;
			}

			// if the item is the tail of the list
			if (iter == _tail)
			{
				// set the tail to the previous item
				_tail = prev;
			}

			// if we are removing the current item move the current item back one
			if (_current == iter)
			{
				_current = prev;
			}

			// shring the size of the list by one
			_size--;

			// release the memory associated with the item
			free(iter);

			// We are done ... so exit
			return;
		}
		else
		{
			// move to the next item
			prev = iter;
			iter = iter->next;
		}
	}
}

// get the head item and be ready to iterate
Instruction* LinkedList::head()
{
	// set current to be the head
	_current = _head;

	// if the head was null
	if (_head == NULL)
	{
		// return null
		return NULL;
	}
	else
	{
		// return the head item
		return _current->item;
	}
}

// get the next item
Instruction* LinkedList::next()
{
	// if no current
	if (_current == NULL)
	{
		// return the head
		return head();
	}

	// get the next item
	_current = _current->next;

	// if the current is nothing
	if (_current == NULL)
	{
		// return nothing
		return NULL;
	}
	else
	{
		// return the item
		return _current->item;
	}
}

// get the number of items in the stack.
short LinkedList::count () const
{
	// return the size
	return _size;
}
