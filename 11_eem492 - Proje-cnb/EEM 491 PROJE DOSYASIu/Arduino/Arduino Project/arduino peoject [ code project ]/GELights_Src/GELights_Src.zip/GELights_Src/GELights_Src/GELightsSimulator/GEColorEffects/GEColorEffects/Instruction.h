#ifndef _INSTRUCTION_H

#define _INSTRUCTION_H

#ifndef PC
	// include necessary header for libraries.
	#include <WProgram.h>
#endif

#include "GEColorEffectsBulb.h"
#include "lightsstring.h"

class LightsString; // forward declare this class due to circular reference

// number of parameters required by each command
static const byte _parameters[]
#ifndef PC
PROGMEM
#endif
	= {	0,
		1,	// Pause
		4,	// SetColour
		1,	// SetAllBrightness
		3,	// AdjustBrightness
		1,	// AdjustAllBrightness
		1,	// SetCycleInterval
		2,	// AdjustCycleInterval
		5,	// FadeColour
		5,	// FadeBrightness
		1,	// DoNothing
		6,	// ShiftBulbs
		6,	// RotateBulbs
		5,	// SetFadeColour
		6,	// copy bulbs
		2,	// loop
		2,   	// debugbreak
		4,	// setvar
		4	// adjustvar
	};

// Base class for all instructions
class Instruction
{
protected:
	LightsString* _string; // the string this instruction is for
	short GetVarOrValue(short var); // Gets a variable value or returns the var as the value
	void SetVar(short var, short val); // Gets a variable value or returns the var as the value

public:
	virtual short Type() = 0;
	virtual bool Done() const = 0;
	virtual void Execute() = 0;
	virtual void Construct(LightsString* string, short args[]) = 0;
	void BaseConstruct(LightsString* string, short args[]);
	static byte Parameters(byte type);
	#ifdef PC
		Instruction() {};
	#endif
};

// Pause the execution for a time
class Pause : public Instruction
{
private:
	short _msecs; // milliseconds to sleep

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 1;};
	#ifdef PC
		Pause() {};
	#endif
};

// Set the colour of bulbs
class SetColour : public Instruction
{
private:
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	short _colour; // the new colour
	byte _brightness; // the new brightness

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 2;};
	#ifdef PC
		SetColour() {};
	#endif
};

// Set the brightness of all bulbs to a value
class SetAllBrightness : public Instruction
{
private:
	byte _brightness; // the new brightness

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 3;};
	#ifdef PC
		SetAllBrightness() {};
	#endif
};

// Adjust the brightness of selected bulbs by an amount
class AdjustBrightness : public Instruction
{
private:
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	short _amount; // the amount to adjust the brightness by

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 4;};
	#ifdef PC
		AdjustBrightness() {};
	#endif
};

// Adjust the brightness of all bulbs by an amount
class AdjustAllBrightness : public Instruction
{
private:
	short _amount; // the amount to adjust the brightness by

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 5;};
	#ifdef PC
		AdjustAllBrightness() {};
	#endif
};

// Set the cycle interval to a given number of milliseconds
class SetCycleInterval : public Instruction
{
private:
	short _msecs; // milliseconds to sleep between cycles

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 6;};
	#ifdef PC
		SetCycleInterval() {};
	#endif
};

// Adjust the cycle interval time by an amount over multiple cycles
class AdjustCycleInterval : public Instruction
{
private:
	short _amount; // the amount of milliseconds to adjust the sleep between cycles by
	short _left; // the number of cycles left

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 7;};
	#ifdef PC
		AdjustCycleInterval() {};
	#endif
};

class ShortFloat
{
	public:
		static float GetFloat(unsigned short i);
		static unsigned short GetShort(unsigned short i);
		static unsigned short SaveFloat(float f);
		static unsigned short SaveShort(unsigned short f);
		static unsigned short Add(unsigned short i, float f);
};

// Fade between 2 colours over multiple cycles
class FadeColour : public Instruction
{
private:
	short _left; // the number of cycles left
	short _cycles; // the number of cycles
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	unsigned short _red; // current red componet
	unsigned short _green; // current green component
	unsigned short _blue; // current blue component
	short _diff;

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 8;};
	#ifdef PC
		FadeColour() {};
	#endif
};

// Fade the brightness of a set of bulbs over time
class FadeBrightness : public Instruction
{
private:
	short _cycles; // the number of cycles to execute for
	short _left; // the number of cycles left
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	//short _startbrightness; // starting brightness
	//short _endbrightness; // starting brightness
	short _brightnessdiff; // change in brightness
	float _brightness; // current brightness

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 9;};
	#ifdef PC
		FadeBrightness() {};
	#endif
};

// do nothing ... also used to terminate a group of parallel instructions
class DoNothing : public Instruction
{
private:
	short _left; // the number of cycles left

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 10;};
	#ifdef PC
		DoNothing() {};
	#endif
};

// shifts bulbs left and right for n cycles ... end is replaced by a given colour
class ShiftBulbs : public Instruction
{
private:
	short _left; // the number of cycles left
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	short _step; // number of bulbs to step when shifting
	short _newcolour; // new bulb colour
	byte _newbrightness; // new bulb brightness
	short _randomcolour;
	byte _randombrightness;

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 11;};
	#ifdef PC
		ShiftBulbs() {};
	#endif
};

// rotates bulbs as if they were in a loop
class RotateBulbs : public Instruction
{
private:
	short _left; // the number of cycles left
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	short _step; // the number of bulbs to step on each cycle
	bool _rotatecolour; // 1 if we are to rotate the colour
	bool _rotatebrightness; // 1 if we are to rotate the brightness

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 12;};
	//~RotateBulbs();
	#ifdef PC
		RotateBulbs() {};
	#endif
};

// Set bulb colours fading colour from start to end
class SetFadeColour : public Instruction
{
private:
	short _startcolour; // the colour to start at
	short _endcolour; // the colour to end at
	byte _startbulb; // the bulb to start at
	byte _endbulb; // the bulb to end at
	byte _brightness; // the brightness to set the bulbs

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 13;};
	#ifdef PC
		SetFadeColour() {};
	#endif
};

// copy bulbs from one location to another
class CopyBulbs : public Instruction
{
private:
	byte _sourcestartbulb; // the bulb to start copying at
	byte _sourceendbulb; // the bulb to end copying at
	byte _targetstartbulb; // the bulb to start copying at
	byte _targetendbulb; // the bulb to end copying at
	bool _copycolour; // 1 if we are to copy the colour
	bool _copybrightness; // 1 if we are to copy the brightness

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 14;};
	#ifdef PC
		CopyBulbs() {};
	#endif
};

// loop back to a tag
class Loop : public Instruction
{
private:
	short _howfar; // number of shorts to jump back
	short _left; // number of times left to loop
	short _id; // id of the loop (basically its instruction address)
	Loop* _loop; // pointer to a copy to dereference to
	LightsString* _ls; // owning lights string

public:
	short Id() { if (_id == -1 && _loop != NULL) { return _loop->Id(); } else { return _id; } };
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	void Setup(LightsString* string, short args[]);
	short Type() { return 15;};
	#ifdef PC
		Loop() {};
	#endif
	Loop* Dereference() { return _loop; };
};

// break when running on PC
class DebugBreakI : public Instruction
{
private:
	short _cycles; // the number of cycles to execute for
	short _left; // the number of cycles left
	bool _breakoneach; // true if we are to break on every cycle

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 16;};
	#ifdef PC
		DebugBreakI() {};
	#endif
};

// set a variable to a value
class SetVariable : public Instruction
{
private:
	short _cycles; // the number of cycles to execute for
	short _left; // the number of cycles left
	bool _setoneach; // true if we are to break on every cycle
	short _var; // variable to set
	short _value; // the value to set

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 17;};
	#ifdef PC
		SetVariable() {};
	#endif
};

// Adjust a variable by an amount
class AdjustVariable : public Instruction
{
private:
	short _cycles; // the number of cycles to execute for
	short _left; // the number of cycles left
	bool _adjustoneach; // true if we are to break on every cycle
	short _var; // variable to adjust
	short _amount; // the amount to adjust by

public:
	bool Done() const;
	void Execute();
	void Construct(LightsString* string, short args[]);
	short Type() { return 18;};
	#ifdef PC
		AdjustVariable() {};
	#endif
};

#endif // _INSTRUCTION_H