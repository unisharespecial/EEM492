
#ifndef _LIGHTSSTRING_H

#define _LIGHTSSTRING_H

#ifndef PC
	// include necessary header for libraries.
	#include <WProgram.h>
	#include <avr/pgmspace.h>
#endif

// forward reference some classes I need pointers to
class LinkedList;
class LinkedListVar;
class Loop;
class Processor;

#include "GEColorEffectsBulb.h"
#include "LinkedList.h"
#include "LinkedListVar.h"

// A string of lights
class LightsString
{
private:
	Bulb* _bulbs[50]; // a representation of each bulb
	Bulb* _allbulbs; // a representation of the broadcast bulb
	LinkedList* _executing; // list of instructions currently executing
	LinkedList* _loops; // list of current active loops
	LinkedListVar* _vars;
	#ifdef PC
		Processor* _processor;
		short* _program; // our program
	#else
		prog_int16_t* _program; // our program
	#endif
	short _ip; // where we are up to in our program

	byte CorrectPin(const byte pin); // adjust the pin number
	Instruction* GetNextInstruction(); // get the next instruction
	#ifdef PC
		short GetData(short* program, short offset);
	#else
		short GetData(prog_int16_t* program, short offset);
	#endif

public:
	#ifdef PC
		LightsString(Processor* p) {_processor = p;};
		void Break();
		void Construct(const byte pin, short* _program);
	#else
		void Construct(const byte pin, prog_int16_t* _program);
	#endif
	LinkedList* Executing();
	Bulb* GetBulb(byte address);
	void Execute();
	void LoadInstructions();
	bool AllDone();
	void AddLoop(Loop* loop);
	inline bool IsValid() { return (_executing != NULL); };
	inline void SetInvalid() { _executing = NULL; };
	void AdjustIP(short howmuch);
	void LoopDone(short id);
	Loop* GetLoop(short id);
	short GetVar(short var);
	void SetVar(short var, short val);
};

#endif // _LIGHTSSTRING_H
