
#ifndef _H_MOTOR_CONTROLLER_
#define _H_MOTOR_CONTROLLER_

enum { null = 0, false = 0, true };
typedef unsigned char bool;

typedef unsigned char byte;
typedef unsigned short word;

#endif //_H_MOTOR_CONTROLLER_
